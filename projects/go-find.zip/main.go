package main

import "go-find/cmd"

func main() {
	cmd.Execute()
}
